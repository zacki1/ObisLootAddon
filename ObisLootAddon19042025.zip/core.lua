_G.ObisLootAddon = LibStub("AceAddon-3.0"):NewAddon("ObisLootAddon", "AceEvent-3.0", "AceConsole-3.0")

ObisLootAddon.Interface = {}
---@class player
ObisLootAddon.Player = {}